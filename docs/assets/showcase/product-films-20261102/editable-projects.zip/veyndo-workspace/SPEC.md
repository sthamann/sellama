# Director specification

GOAL: Prepare the wool coat, inspect its storefront, edit privately and publish selected content.
OUTPUT: HyperFrames HTML; 1920 × 1080; 30 fps; silent MP4.
TIME: 96 seconds × 30 = 2880 frames.
LOOK: white #FFFFFF ground, ink #132B3A, approved #189EFF brand blue; text accent #0068B5 for contrast. Inter 750 display at 68–92px, body 34px, subtitles 35px. Actual UI pixels unchanged. 120px content margins; 192px subtitle margins. Focus crops explain one area at a time. Rounded image window 22px, shadow 0/18/52 at 11%.
OBJECTS: actual Veyndo product screens and approved Living V logo; flat diagram shapes only for architecture, never fake controls.
MOTION: power3.out entrances 0.65s, power2.inOut focus transitions 1.1s, 0.22s screenshot handoffs; titles stop while reading. Finite per-shot progress line.
BANNED: gradients, dark voids, glow, particles, stock photos, redrawn logo, fake UI, invented performance claims, prompt-typing opener, tiny whole-screen menu tours, audio, illegible caption walls.
QA: inspect every scene midpoint and every cut ±0.2s; phone sheet; decode final MP4 frames; verify exact duration, H.264 1080p30 and no audio stream. UI interaction is an editorial sequence of still captures, never a real-time recording claim.

SHOTS:

| Time | Scene | Medium | First explanatory line |
| --- | --- | --- | --- |
| 00–12s | veyndo-workspace-1 | actual UI | The compact product editor brings the essential work together. |
| 12–24s | veyndo-workspace-2 | actual UI | Arrange the product media and inspect the selected image. |
| 24–36s | veyndo-workspace-3 | actual UI | Review the effective title, page URL and description as you edit. |
| 36–48s | veyndo-workspace-4 | actual UI | Select related products from the same native catalogue. |
| 48–60s | veyndo-workspace-5 | actual UI | The customer sees product media, content, price and available sizes. |
| 60–72s | veyndo-workspace-6 | actual UI | Select the page section and edit with the preview beside you. |
| 72–84s | veyndo-workspace-7 | actual UI | A private content edit is reviewed through the existing release path. |
| 84–96s | veyndo-workspace-8 | actual UI | The saved product history provides a route back to earlier content. |
