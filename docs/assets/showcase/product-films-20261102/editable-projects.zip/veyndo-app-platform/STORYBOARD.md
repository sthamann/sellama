# Shot plan

| Time | Scene | Medium | First explanatory line |
| --- | --- | --- | --- |
| 00–12s | veyndo-app-platform-1 | actual UI | Start with the views and placements this app needs. |
| 12–24s | veyndo-app-platform-2 | actual UI | Arrange components and select the element you want to change. |
| 24–36s | veyndo-app-platform-3 | actual UI | Open the contextual coding assistant without leaving the app. |
| 36–48s | veyndo-app-platform-4 | actual UI | Define the values a merchant supplies after installing the app. |
| 48–60s | veyndo-app-platform-5 | actual UI | Define app fields and their relationships to native commerce objects. |
| 60–72s | veyndo-app-platform-6 | actual UI | Connect the app behaviour to the native action and event contracts. |
| 72–84s | veyndo-app-platform-7 | actual UI | The real preview saves care guidance for the selected product. |
