# Narrative options

1. **Outcome → how → control → invitation. Selected.** Connect actual merchant and buyer work to a shared foundation.
2. Feature-by-feature menu tour. Rejected: weak causality and tiny UI text.
3. Abstract AI vision film. Rejected: lacks proof of the implemented product.

The request is for completed films; production proceeds with the first direction.
