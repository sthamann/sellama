# Director specification

GOAL: Follow the Product advisor through its placements, visual editor, assistant, settings, data and saved record.
OUTPUT: HyperFrames HTML; 1920 × 1080; 30 fps; silent MP4.
TIME: 84 seconds × 30 = 2520 frames.
LOOK: white #FFFFFF ground, ink #132B3A, approved #189EFF brand blue; text accent #0068B5 for contrast. Inter 750 display at 68–92px, body 34px, subtitles 35px. Actual UI pixels unchanged. 120px content margins; 192px subtitle margins. Focus crops explain one area at a time. Rounded image window 22px, shadow 0/18/52 at 11%.
OBJECTS: actual Veyndo product screens and approved Living V logo; flat diagram shapes only for architecture, never fake controls.
MOTION: power3.out entrances 0.65s, power2.inOut focus transitions 1.1s, 0.22s screenshot handoffs; titles stop while reading. Finite per-shot progress line.
BANNED: gradients, dark voids, glow, particles, stock photos, redrawn logo, fake UI, invented performance claims, prompt-typing opener, tiny whole-screen menu tours, audio, illegible caption walls.
QA: inspect every scene midpoint and every cut ±0.2s; phone sheet; decode final MP4 frames; verify exact duration, H.264 1080p30 and no audio stream. UI interaction is an editorial sequence of still captures, never a real-time recording claim.

SHOTS:

| Time | Scene | Medium | First explanatory line |
| --- | --- | --- | --- |
| 00–12s | veyndo-app-platform-1 | actual UI | Start with the views and placements this app needs. |
| 12–24s | veyndo-app-platform-2 | actual UI | Arrange components and select the element you want to change. |
| 24–36s | veyndo-app-platform-3 | actual UI | Open the contextual coding assistant without leaving the app. |
| 36–48s | veyndo-app-platform-4 | actual UI | Define the values a merchant supplies after installing the app. |
| 48–60s | veyndo-app-platform-5 | actual UI | Define app fields and their relationships to native commerce objects. |
| 60–72s | veyndo-app-platform-6 | actual UI | Connect the app behaviour to the native action and event contracts. |
| 72–84s | veyndo-app-platform-7 | actual UI | The real preview saves care guidance for the selected product. |
