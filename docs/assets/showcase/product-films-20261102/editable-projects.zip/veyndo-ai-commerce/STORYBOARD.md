# Shot plan

| Time | Scene | Medium | First explanatory line |
| --- | --- | --- | --- |
| 00–14s | veyndo-ai-commerce-1 | actual UI | The merchant workspace connects conversation and native shop tools. |
| 14–28s | veyndo-ai-commerce-2 | actual UI | See sources, catalogue knowledge and the available shop connections together. |
| 28–42s | veyndo-ai-commerce-3 | actual UI | A product or shop URL opens the existing catalogue intake. |
| 42–56s | veyndo-ai-commerce-4 | actual UI | Provide a shop URL, screenshot or design reference in the shop editor. |
| 56–70s | veyndo-ai-commerce-5 | actual UI | The canvas connects the home page, product page and category. |
| 70–84s | veyndo-ai-commerce-6 | actual UI | The app assistant works with the selected app and versioned draft. |
| 84–98s | veyndo-ai-commerce-7 | actual UI | The agentic commerce area brings customer scenarios into the shop context. |
| 98–116s | veyndo-ai-commerce-8 | actual UI | Agent suggestions and manual edits follow the same reviewable route. |
