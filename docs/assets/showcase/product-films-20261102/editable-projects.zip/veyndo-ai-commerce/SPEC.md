# Director specification

GOAL: Connect merchant intake, reviewed knowledge, design references, app assistance and fictional buyer setup.
OUTPUT: HyperFrames HTML; 1920 × 1080; 30 fps; silent MP4.
TIME: 116 seconds × 30 = 3480 frames.
LOOK: white #FFFFFF ground, ink #132B3A, approved #189EFF brand blue; text accent #0068B5 for contrast. Inter 750 display at 68–92px, body 34px, subtitles 35px. Actual UI pixels unchanged. 120px content margins; 192px subtitle margins. Focus crops explain one area at a time. Rounded image window 22px, shadow 0/18/52 at 11%.
OBJECTS: actual Veyndo product screens and approved Living V logo; flat diagram shapes only for architecture, never fake controls.
MOTION: power3.out entrances 0.65s, power2.inOut focus transitions 1.1s, 0.22s screenshot handoffs; titles stop while reading. Finite per-shot progress line.
BANNED: gradients, dark voids, glow, particles, stock photos, redrawn logo, fake UI, invented performance claims, prompt-typing opener, tiny whole-screen menu tours, audio, illegible caption walls.
QA: inspect every scene midpoint and every cut ±0.2s; phone sheet; decode final MP4 frames; verify exact duration, H.264 1080p30 and no audio stream. UI interaction is an editorial sequence of still captures, never a real-time recording claim.

SHOTS:

| Time | Scene | Medium | First explanatory line |
| --- | --- | --- | --- |
| 00–14s | veyndo-ai-commerce-1 | actual UI | The merchant workspace connects conversation and native shop tools. |
| 14–28s | veyndo-ai-commerce-2 | actual UI | See sources, catalogue knowledge and the available shop connections together. |
| 28–42s | veyndo-ai-commerce-3 | actual UI | A product or shop URL opens the existing catalogue intake. |
| 42–56s | veyndo-ai-commerce-4 | actual UI | Provide a shop URL, screenshot or design reference in the shop editor. |
| 56–70s | veyndo-ai-commerce-5 | actual UI | The canvas connects the home page, product page and category. |
| 70–84s | veyndo-ai-commerce-6 | actual UI | The app assistant works with the selected app and versioned draft. |
| 84–98s | veyndo-ai-commerce-7 | actual UI | The agentic commerce area brings customer scenarios into the shop context. |
| 98–116s | veyndo-ai-commerce-8 | actual UI | Agent suggestions and manual edits follow the same reviewable route. |
