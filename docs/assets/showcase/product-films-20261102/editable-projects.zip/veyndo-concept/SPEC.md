# Director specification

GOAL: Follow one wool coat through native commerce, merchant tools, an app, visual design and a simulated order.
OUTPUT: HyperFrames HTML; 1920 × 1080; 30 fps; silent MP4.
TIME: 72 seconds × 30 = 2160 frames.
LOOK: white #FFFFFF ground, ink #132B3A, approved #189EFF brand blue; text accent #0068B5 for contrast. Inter 750 display at 68–92px, body 34px, subtitles 35px. Actual UI pixels unchanged. 120px content margins; 192px subtitle margins. Focus crops explain one area at a time. Rounded image window 22px, shadow 0/18/52 at 11%.
OBJECTS: actual Veyndo product screens and approved Living V logo; flat diagram shapes only for architecture, never fake controls.
MOTION: power3.out entrances 0.65s, power2.inOut focus transitions 1.1s, 0.22s screenshot handoffs; titles stop while reading. Finite per-shot progress line.
BANNED: gradients, dark voids, glow, particles, stock photos, redrawn logo, fake UI, invented performance claims, prompt-typing opener, tiny whole-screen menu tours, audio, illegible caption walls.
QA: inspect every scene midpoint and every cut ±0.2s; phone sheet; decode final MP4 frames; verify exact duration, H.264 1080p30 and no audio stream. UI interaction is an editorial sequence of still captures, never a real-time recording claim.

SHOTS:

| Time | Scene | Medium | First explanatory line |
| --- | --- | --- | --- |
| 00–12s | veyndo-concept-1 | actual UI | The wool coat connects product content, media and selling channels. |
| 12–24s | veyndo-concept-2 | actual UI | The merchant assistant sits beside catalogue intake and shop tools. |
| 24–36s | veyndo-concept-3 | actual UI | Keep the working views you use close to your daily tasks. |
| 36–48s | veyndo-concept-4 | actual UI | A product advisor stores care guidance for the wool coat. |
| 48–60s | veyndo-concept-5 | actual UI | See the home page, product page and category together. |
| 60–72s | veyndo-concept-6 | actual UI | The same catalogue reaches the native checkout and saved order. |
