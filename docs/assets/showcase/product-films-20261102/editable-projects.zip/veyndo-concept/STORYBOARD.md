# Shot plan

| Time | Scene | Medium | First explanatory line |
| --- | --- | --- | --- |
| 00–12s | veyndo-concept-1 | actual UI | The wool coat connects product content, media and selling channels. |
| 12–24s | veyndo-concept-2 | actual UI | The merchant assistant sits beside catalogue intake and shop tools. |
| 24–36s | veyndo-concept-3 | actual UI | Keep the working views you use close to your daily tasks. |
| 36–48s | veyndo-concept-4 | actual UI | A product advisor stores care guidance for the wool coat. |
| 48–60s | veyndo-concept-5 | actual UI | See the home page, product page and category together. |
| 60–72s | veyndo-concept-6 | actual UI | The same catalogue reaches the native checkout and saved order. |
