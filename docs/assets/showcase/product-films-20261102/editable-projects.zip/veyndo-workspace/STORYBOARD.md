# Shot plan

| Time | Scene | Medium | First explanatory line |
| --- | --- | --- | --- |
| 00–12s | veyndo-workspace-1 | actual UI | The compact product editor brings the essential work together. |
| 12–24s | veyndo-workspace-2 | actual UI | Arrange the product media and inspect the selected image. |
| 24–36s | veyndo-workspace-3 | actual UI | Review the effective title, page URL and description as you edit. |
| 36–48s | veyndo-workspace-4 | actual UI | Select related products from the same native catalogue. |
| 48–60s | veyndo-workspace-5 | actual UI | The customer sees product media, content, price and available sizes. |
| 60–72s | veyndo-workspace-6 | actual UI | Select the page section and edit with the preview beside you. |
| 72–84s | veyndo-workspace-7 | actual UI | A private content edit is reviewed through the existing release path. |
| 84–96s | veyndo-workspace-8 | actual UI | The saved product history provides a route back to earlier content. |
